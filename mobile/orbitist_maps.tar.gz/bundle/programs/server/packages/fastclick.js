(function () {

/* Imports */
var Meteor = Package.meteor.Meteor;



/* Exports */
if (typeof Package === 'undefined') Package = {};
Package.fastclick = {};

})();

//# sourceMappingURL=fastclick.js.map
