(function () {

/* Imports */
var Meteor = Package.meteor.Meteor;



/* Exports */
if (typeof Package === 'undefined') Package = {};
Package['luisalmeida:unveil'] = {};

})();

//# sourceMappingURL=luisalmeida_unveil.js.map
